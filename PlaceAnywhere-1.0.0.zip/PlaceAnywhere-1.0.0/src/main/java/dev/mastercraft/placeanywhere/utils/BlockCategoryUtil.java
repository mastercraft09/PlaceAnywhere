package dev.mastercraft.placeanywhere.utils;

import dev.mastercraft.placeanywhere.managers.ConfigManager.BlockCategory;
import org.bukkit.Material;
import org.bukkit.Tag;

import java.util.EnumSet;
import java.util.Set;

public class BlockCategoryUtil {

        private static final Set<Material> PLANTS = EnumSet.of(
            Material.SHORT_GRASS, Material.TALL_GRASS,
            Material.FERN, Material.LARGE_FERN,
            Material.DEAD_BUSH
    );

    private static final Set<Material> TALL_PLANTS = EnumSet.of(
            Material.TALL_GRASS, Material.LARGE_FERN,
            Material.SUNFLOWER, Material.LILAC,
            Material.ROSE_BUSH, Material.PEONY,
            Material.PITCHER_PLANT
    );

    private static final Set<Material> FLOWERS = EnumSet.of(
            Material.DANDELION, Material.POPPY,
            Material.BLUE_ORCHID, Material.ALLIUM,
            Material.AZURE_BLUET, Material.RED_TULIP,
            Material.ORANGE_TULIP, Material.WHITE_TULIP,
            Material.PINK_TULIP, Material.OXEYE_DAISY,
            Material.CORNFLOWER, Material.LILY_OF_THE_VALLEY,
            Material.WITHER_ROSE, Material.TORCHFLOWER,
            Material.PINK_PETALS
    );

    private static final Set<Material> MUSHROOMS = EnumSet.of(
            Material.BROWN_MUSHROOM, Material.RED_MUSHROOM
    );

    private static final Set<Material> FUNGI = EnumSet.of(
            Material.CRIMSON_FUNGUS, Material.WARPED_FUNGUS,
            Material.NETHER_SPROUTS
    );

    private static final Set<Material> NETHER_PLANTS = EnumSet.of(
            Material.NETHER_WART,
            Material.WEEPING_VINES, Material.WEEPING_VINES_PLANT,
            Material.TWISTING_VINES, Material.TWISTING_VINES_PLANT
    );

    private static final Set<Material> AQUATIC = EnumSet.of(
            Material.SEAGRASS, Material.TALL_SEAGRASS,
            Material.KELP, Material.KELP_PLANT,
            Material.SEA_PICKLE,
            Material.TUBE_CORAL, Material.BRAIN_CORAL,
            Material.BUBBLE_CORAL, Material.FIRE_CORAL,
            Material.HORN_CORAL,
            Material.TUBE_CORAL_FAN, Material.BRAIN_CORAL_FAN,
            Material.BUBBLE_CORAL_FAN, Material.FIRE_CORAL_FAN,
            Material.HORN_CORAL_FAN,
            Material.DEAD_TUBE_CORAL, Material.DEAD_BRAIN_CORAL,
            Material.DEAD_BUBBLE_CORAL, Material.DEAD_FIRE_CORAL,
            Material.DEAD_HORN_CORAL,
            Material.DEAD_TUBE_CORAL_FAN, Material.DEAD_BRAIN_CORAL_FAN,
            Material.DEAD_BUBBLE_CORAL_FAN, Material.DEAD_FIRE_CORAL_FAN,
            Material.DEAD_HORN_CORAL_FAN
    );

    private static final Set<Material> TORCHES = EnumSet.of(
            Material.TORCH, Material.WALL_TORCH,
            Material.SOUL_TORCH, Material.SOUL_WALL_TORCH,
            Material.REDSTONE_TORCH, Material.REDSTONE_WALL_TORCH
    );

    private static final Set<Material> CROPS = EnumSet.of(
            Material.WHEAT, Material.CARROTS,
            Material.POTATOES, Material.BEETROOTS,
            Material.MELON_STEM, Material.PUMPKIN_STEM,
            Material.SUGAR_CANE, Material.BAMBOO,
            Material.BAMBOO_SAPLING,
            Material.SWEET_BERRY_BUSH,
            Material.COCOA, Material.PITCHER_POD,
            Material.TORCHFLOWER_CROP
    );

    private static final Set<Material> VINES = EnumSet.of(
            Material.VINE, Material.GLOW_LICHEN,
            Material.CAVE_VINES, Material.CAVE_VINES_PLANT,
            Material.HANGING_ROOTS, Material.SPORE_BLOSSOM,
            Material.BIG_DRIPLEAF, Material.SMALL_DRIPLEAF
    );

    private static final Set<Material> DECORATIONS = EnumSet.of(
            Material.ITEM_FRAME, Material.GLOW_ITEM_FRAME,
            Material.PAINTING,
            Material.LADDER,
            Material.LANTERN, Material.SOUL_LANTERN,
            Material.CHAIN,
            Material.BELL,
            Material.FLOWER_POT,
            Material.LILY_PAD,
            Material.END_ROD,
            Material.LIGHTNING_ROD,
            Material.LEVER,
            Material.TRIPWIRE_HOOK,
            Material.STONE_BUTTON, Material.OAK_BUTTON,
            Material.SPRUCE_BUTTON, Material.BIRCH_BUTTON,
            Material.JUNGLE_BUTTON, Material.ACACIA_BUTTON,
            Material.DARK_OAK_BUTTON, Material.MANGROVE_BUTTON,
            Material.CHERRY_BUTTON, Material.BAMBOO_BUTTON,
            Material.CRIMSON_BUTTON, Material.WARPED_BUTTON,
            Material.POLISHED_BLACKSTONE_BUTTON
    );

        public static BlockCategory getCategory(Material material) {
        if (TALL_PLANTS.contains(material)) return BlockCategory.TALL_PLANTS;
        if (PLANTS.contains(material)) return BlockCategory.PLANTS;
        if (FLOWERS.contains(material)) return BlockCategory.FLOWERS;
        if (MUSHROOMS.contains(material)) return BlockCategory.MUSHROOMS;
        if (FUNGI.contains(material)) return BlockCategory.FUNGI;
        if (NETHER_PLANTS.contains(material)) return BlockCategory.NETHER_PLANTS;
        if (AQUATIC.contains(material)) return BlockCategory.AQUATIC;
        if (TORCHES.contains(material)) return BlockCategory.TORCHES;
        if (CROPS.contains(material)) return BlockCategory.CROPS;
        if (VINES.contains(material)) return BlockCategory.VINES;
        if (DECORATIONS.contains(material)) return BlockCategory.DECORATIONS;

                if (Tag.SAPLINGS.isTagged(material)) return BlockCategory.PLANTS;
        if (Tag.FLOWERS.isTagged(material)) return BlockCategory.FLOWERS;

        return null; 
    }

        public static boolean isRestrictedBlock(Material material) {
        return getCategory(material) != null;
    }

        public static Material getWallVariant(Material material) {
        return switch (material) {
            case TORCH -> Material.WALL_TORCH;
            case SOUL_TORCH -> Material.SOUL_WALL_TORCH;
            case REDSTONE_TORCH -> Material.REDSTONE_WALL_TORCH;
            default -> null;
        };
    }
}
