package dev.mastercraft.placeanywhere;

import dev.mastercraft.placeanywhere.commands.PlaceAnywhereCommand;
import dev.mastercraft.placeanywhere.listeners.BlockPlaceListener;
import dev.mastercraft.placeanywhere.managers.ConfigManager;
import dev.mastercraft.placeanywhere.managers.PlayerDataManager;
import dev.mastercraft.placeanywhere.utils.MessageUtil;
import org.bukkit.plugin.java.JavaPlugin;

public final class PlaceAnywhere extends JavaPlugin {

    private static PlaceAnywhere instance;
    private ConfigManager configManager;
    private PlayerDataManager playerDataManager;

    @Override
    public void onEnable() {
        instance = this;

                saveDefaultConfig();

                configManager = new ConfigManager(this);
        playerDataManager = new PlayerDataManager(this);

                playerDataManager.load();

                getServer().getPluginManager().registerEvents(new BlockPlaceListener(this), this);

                PlaceAnywhereCommand cmd = new PlaceAnywhereCommand(this);
        getCommand("placeanywhere").setExecutor(cmd);
        getCommand("placeanywhere").setTabCompleter(cmd);

        getLogger().info("╔═══════════════════════════════╗");
        getLogger().info("║     PlaceAnywhere v" + getDescription().getVersion() + "      ║");
        getLogger().info("║     Autore: MasterCraft       ║");
        getLogger().info("║     Stato: ATTIVO ✔            ║");
        getLogger().info("╚═══════════════════════════════╝");
    }

    @Override
    public void onDisable() {
        if (playerDataManager != null) {
            playerDataManager.save();
        }
        getLogger().info("[PlaceAnywhere] Plugin disabilitato. Dati salvati.");
    }

    public static PlaceAnywhere getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public void reload() {
        reloadConfig();
        configManager.reload();
        playerDataManager.load();
    }
}
