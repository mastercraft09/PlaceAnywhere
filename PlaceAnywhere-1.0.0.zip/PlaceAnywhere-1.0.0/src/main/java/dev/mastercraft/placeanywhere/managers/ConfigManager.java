package dev.mastercraft.placeanywhere.managers;

import dev.mastercraft.placeanywhere.PlaceAnywhere;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ConfigManager {

    private final PlaceAnywhere plugin;
    private FileConfiguration config;

        private boolean logPlacements;
    private boolean notifyAdmins;
    private boolean showToggleFeedback;
    private String feedbackType;
    private boolean soundEnabled;
    private String soundOn;
    private String soundOff;
    private String placementParticle;
    private int particleCount;
    private boolean forcPlace;
    private boolean aggressiveMode;
    private boolean bypassProtectionPlugins;
    private boolean enabledByDefault;
    private String defaultMode;
    private Set<Material> blacklistedBlocks;

        private boolean catPlants;
    private boolean catTallPlants;
    private boolean catFlowers;
    private boolean catMushrooms;
    private boolean catFungi;
    private boolean catNetherPlants;
    private boolean catAquatic;
    private boolean catDecorations;
    private boolean catTorches;
    private boolean catCrops;
    private boolean catVines;
    private boolean catOther;

    public ConfigManager(PlaceAnywhere plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        plugin.reloadConfig();
        this.config = plugin.getConfig();
        loadValues();
    }

    private void loadValues() {
        logPlacements = config.getBoolean("settings.log-placements", false);
        notifyAdmins = config.getBoolean("settings.notify-admins", true);
        showToggleFeedback = config.getBoolean("settings.show-toggle-feedback", true);
        feedbackType = config.getString("settings.feedback-type", "ACTIONBAR");
        soundEnabled = config.getBoolean("settings.sound-enabled", true);
        soundOn = config.getString("settings.sound-on", "BLOCK_NOTE_BLOCK_PLING");
        soundOff = config.getString("settings.sound-off", "BLOCK_NOTE_BLOCK_BASS");
        placementParticle = config.getString("settings.placement-particle", "VILLAGER_HAPPY");
        particleCount = config.getInt("settings.particle-count", 5);

        forcPlace = config.getBoolean("placement.force-place", true);
        aggressiveMode = config.getBoolean("placement.aggressive-mode", true);
        bypassProtectionPlugins = config.getBoolean("placement.bypass-protection-plugins", false);
        enabledByDefault = config.getBoolean("settings.enabled-by-default", false);
        defaultMode = config.getString("settings.default-mode", "TOGGLE");

                blacklistedBlocks = new HashSet<>();
        List<String> blacklist = config.getStringList("placement.blacklisted-blocks");
        for (String s : blacklist) {
            try {
                Material m = Material.valueOf(s.toUpperCase());
                blacklistedBlocks.add(m);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("Material non valido nella blacklist: " + s);
            }
        }

                catPlants = config.getBoolean("placement.categories.plants", true);
        catTallPlants = config.getBoolean("placement.categories.tall-plants", true);
        catFlowers = config.getBoolean("placement.categories.flowers", true);
        catMushrooms = config.getBoolean("placement.categories.mushrooms", true);
        catFungi = config.getBoolean("placement.categories.fungi", true);
        catNetherPlants = config.getBoolean("placement.categories.nether-plants", true);
        catAquatic = config.getBoolean("placement.categories.aquatic", true);
        catDecorations = config.getBoolean("placement.categories.decorations", true);
        catTorches = config.getBoolean("placement.categories.torches", true);
        catCrops = config.getBoolean("placement.categories.crops", true);
        catVines = config.getBoolean("placement.categories.vines", true);
        catOther = config.getBoolean("placement.categories.other", true);
    }

    public String getMessage(String path) {
        String prefix = config.getString("messages.prefix", "&8[&6PlaceAnywhere&8] &r");
        String msg = config.getString("messages." + path, "&cMessaggio mancante: " + path);
        return colorize(prefix + msg);
    }

    public String getRawMessage(String path) {
        return colorize(config.getString("messages." + path, "&cMessaggio mancante: " + path));
    }

    private String colorize(String s) {
        return s.replace("&", "§");
    }

    public boolean isLogPlacements() { return logPlacements; }
    public boolean isNotifyAdmins() { return notifyAdmins; }
    public boolean isShowToggleFeedback() { return showToggleFeedback; }
    public String getFeedbackType() { return feedbackType; }
    public boolean isSoundEnabled() { return soundEnabled; }
    public String getSoundOn() { return soundOn; }
    public String getSoundOff() { return soundOff; }
    public String getPlacementParticle() { return placementParticle; }
    public int getParticleCount() { return particleCount; }
    public boolean isForcePlace() { return forcPlace; }
    public boolean isAggressiveMode() { return aggressiveMode; }
    public boolean isBypassProtectionPlugins() { return bypassProtectionPlugins; }
    public boolean isEnabledByDefault() { return enabledByDefault; }
    public String getDefaultMode() { return defaultMode; }
    public Set<Material> getBlacklistedBlocks() { return blacklistedBlocks; }

    public boolean isCategoryEnabled(BlockCategory category) {
        return switch (category) {
            case PLANTS -> catPlants;
            case TALL_PLANTS -> catTallPlants;
            case FLOWERS -> catFlowers;
            case MUSHROOMS -> catMushrooms;
            case FUNGI -> catFungi;
            case NETHER_PLANTS -> catNetherPlants;
            case AQUATIC -> catAquatic;
            case DECORATIONS -> catDecorations;
            case TORCHES -> catTorches;
            case CROPS -> catCrops;
            case VINES -> catVines;
            case OTHER -> catOther;
        };
    }

    public enum BlockCategory {
        PLANTS, TALL_PLANTS, FLOWERS, MUSHROOMS, FUNGI,
        NETHER_PLANTS, AQUATIC, DECORATIONS, TORCHES,
        CROPS, VINES, OTHER
    }
}
