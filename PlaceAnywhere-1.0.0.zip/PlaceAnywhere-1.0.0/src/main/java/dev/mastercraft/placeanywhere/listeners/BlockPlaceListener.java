package dev.mastercraft.placeanywhere.listeners;

import dev.mastercraft.placeanywhere.PlaceAnywhere;
import dev.mastercraft.placeanywhere.managers.ConfigManager;
import dev.mastercraft.placeanywhere.managers.ConfigManager.BlockCategory;
import dev.mastercraft.placeanywhere.managers.PlayerDataManager;
import dev.mastercraft.placeanywhere.utils.BlockCategoryUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.type.Bamboo;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockCanBuildEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class BlockPlaceListener implements Listener {

    private final PlaceAnywhere plugin;
    private final ConfigManager config;
    private final PlayerDataManager playerData;

        private final Set<Long> forcedLocations = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public BlockPlaceListener(PlaceAnywhere plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfigManager();
        this.playerData = plugin.getPlayerDataManager();
    }

                    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockCanBuild(BlockCanBuildEvent event) {
        if (event.getPlayer() == null) return;
        Player player = event.getPlayer();
        if (!playerData.isActive(player)) return;

        Material material = event.getMaterial();
        if (config.getBlacklistedBlocks().contains(material)) return;

        BlockCategory category = BlockCategoryUtil.getCategory(material);
        if (category != null && !config.isCategoryEnabled(category)) return;

        event.setBuildable(true);
    }

                    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (!playerData.isActive(player)) return;

        Material material = event.getBlockPlaced().getType();

        if (config.getBlacklistedBlocks().contains(material)) {
            event.setCancelled(true);
            player.sendMessage(config.getMessage("blacklisted-block"));
            return;
        }

        BlockCategory category = BlockCategoryUtil.getCategory(material);
        if (category == null) return;
        if (!config.isCategoryEnabled(category)) return;

        if (event.isCancelled()) {
            event.setCancelled(false);
        }

                        Block placed = event.getBlockPlaced();
        long key = locationKey(placed);
        forcedLocations.add(key);
        Bukkit.getScheduler().runTaskLater(plugin, () -> forcedLocations.remove(key), 2L);
    }

                            @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        if (!playerData.isActive(player)) return;

        Block clicked = event.getClickedBlock();
        if (clicked == null) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType().isAir()) return;

        Material material = item.getType();
        if (!material.isBlock()) return;

        if (config.getBlacklistedBlocks().contains(material)) return;

        BlockCategory category = BlockCategoryUtil.getCategory(material);
        if (category == null) return;
        if (!config.isCategoryEnabled(category)) return;

        BlockFace face = event.getBlockFace();
        Block target = clicked.getRelative(face);

        if (!isReplaceable(target)) return;

        final Block finalTarget = target;
        final BlockFace finalFace = face;

        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!isReplaceable(finalTarget) && finalTarget.getType() != material) return;

            BlockData data = buildBlockData(material, finalTarget, player, finalFace);

                        long key = locationKey(finalTarget);
            forcedLocations.add(key);
            finalTarget.setBlockData(data, false);

                        if (isTallPlant(material)) {
                forcedLocations.add(locationKey(finalTarget.getRelative(BlockFace.UP)));
            }

                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                forcedLocations.remove(key);
                forcedLocations.remove(locationKey(finalTarget.getRelative(BlockFace.UP)));
            }, 2L);

                        if (player.getGameMode() == GameMode.SURVIVAL) {
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand.getAmount() > 1) {
                    hand.setAmount(hand.getAmount() - 1);
                } else {
                    player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
                }
                player.updateInventory();
            }

            handleSuccess(player, finalTarget);
        });
    }

                private BlockData buildBlockData(Material material, Block block, Player player, BlockFace face) {
        if (isTallPlant(material)) {
            return handleTallPlant(material, block);
        }

        if (material == Material.BAMBOO) {
            Bamboo bamboo = (Bamboo) Bukkit.createBlockData(Material.BAMBOO);
            bamboo.setLeaves(Bamboo.Leaves.NONE);
            return bamboo;
        }

                if (material == Material.TORCH || material == Material.SOUL_TORCH || material == Material.REDSTONE_TORCH) {
            Material wallVariant = BlockCategoryUtil.getWallVariant(material);
            if (wallVariant != null && isHorizontalFace(face)) {
                try {
                    Directional dir = (Directional) Bukkit.createBlockData(wallVariant);
                    dir.setFacing(face);
                    return dir;
                } catch (Exception e) {
                    return Bukkit.createBlockData(wallVariant);
                }
            }
        }

        return Bukkit.createBlockData(material);
    }

    private BlockData handleTallPlant(Material material, Block block) {
        Bisected data;
        try {
            data = (Bisected) Bukkit.createBlockData(material);
            data.setHalf(Bisected.Half.BOTTOM);
        } catch (ClassCastException | IllegalArgumentException e) {
            return Bukkit.createBlockData(material);
        }

        Block upperBlock = block.getRelative(BlockFace.UP);
        if (isReplaceable(upperBlock)) {
            try {
                Bisected upperData = (Bisected) Bukkit.createBlockData(material);
                upperData.setHalf(Bisected.Half.TOP);
                upperBlock.setBlockData(upperData, false);
            } catch (Exception ignored) {}
        }

        return data;
    }

    private boolean isTallPlant(Material material) {
        return switch (material) {
            case TALL_GRASS, LARGE_FERN, SUNFLOWER, LILAC,
                    ROSE_BUSH, PEONY, TALL_SEAGRASS -> true;
            default -> false;
        };
    }

                @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPhysics(BlockPhysicsEvent event) {
        if (forcedLocations.contains(locationKey(event.getBlock()))) {
            event.setCancelled(true);
        }
    }

    private long locationKey(Block block) {
                        return ((long) block.getWorld().hashCode() << 32)
                ^ ((long)(block.getX() & 0x3FFFF) << 18)
                ^ ((long)(block.getY() & 0x1FF) << 9)
                ^ (block.getZ() & 0x1FF);
    }

    private boolean isReplaceable(Block block) {
        Material t = block.getType();
        return t == Material.AIR
                || t == Material.CAVE_AIR
                || t == Material.VOID_AIR
                || t == Material.WATER
                || t == Material.LAVA;
    }

    private boolean isHorizontalFace(BlockFace face) {
        return face == BlockFace.NORTH || face == BlockFace.SOUTH
                || face == BlockFace.EAST || face == BlockFace.WEST;
    }

                private void handleSuccess(Player player, Block block) {
        playerData.incrementPlacementCount(player);

        if (config.isLogPlacements()) {
            plugin.getLogger().info("[PlaceAnywhere] " + player.getName()
                    + " ha piazzato " + block.getType()
                    + " in " + block.getLocation().getBlockX()
                    + "," + block.getLocation().getBlockY()
                    + "," + block.getLocation().getBlockZ()
                    + " (" + block.getWorld().getName() + ")");
        }

        spawnParticles(player, block);
        playPlacementSound(player);
    }

    private void spawnParticles(Player player, Block block) {
        String particleName = config.getPlacementParticle();
        if (particleName.equalsIgnoreCase("NONE")) return;
        try {
            Particle particle = Particle.valueOf(particleName.toUpperCase());
            Location loc = block.getLocation().add(0.5, 0.5, 0.5);
            player.getWorld().spawnParticle(particle, loc, config.getParticleCount(), 0.3, 0.3, 0.3, 0);
        } catch (IllegalArgumentException ignored) {}
    }

    private void playPlacementSound(Player player) {
        if (!config.isSoundEnabled()) return;
        try {
            player.playSound(player.getLocation(), Sound.valueOf("BLOCK_GRASS_PLACE"), 0.4f, 1.2f);
        } catch (IllegalArgumentException ignored) {}
    }

                @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (playerData.isActive(player)) {
            playerData.enable(player);
        } else if (config.isEnabledByDefault() && player.hasPermission("placeanywhere.toggle")) {
            playerData.enable(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        playerData.onPlayerQuit(event.getPlayer());
    }
}
