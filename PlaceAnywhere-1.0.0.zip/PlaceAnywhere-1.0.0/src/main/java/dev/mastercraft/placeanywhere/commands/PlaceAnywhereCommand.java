package dev.mastercraft.placeanywhere.commands;

import dev.mastercraft.placeanywhere.PlaceAnywhere;
import dev.mastercraft.placeanywhere.managers.ConfigManager;
import dev.mastercraft.placeanywhere.managers.PlayerDataManager;
import dev.mastercraft.placeanywhere.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class PlaceAnywhereCommand implements CommandExecutor, TabCompleter {

    private final PlaceAnywhere plugin;
    private final ConfigManager config;
    private final PlayerDataManager playerData;

    public PlaceAnywhereCommand(PlaceAnywhere plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfigManager();
        this.playerData = plugin.getPlayerDataManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

                if (args.length == 0 || args[0].equalsIgnoreCase("toggle")) {
            return handleToggle(sender, null);
        }

        switch (args[0].toLowerCase()) {
            case "on" -> { return handleSetState(sender, null, true); }
            case "off" -> { return handleSetState(sender, null, false); }
            case "reload" -> { return handleReload(sender); }
            case "info" -> { return handleInfo(sender); }
            case "list" -> { return handleList(sender); }
            case "toggle" -> {
                if (args.length > 1) return handleToggle(sender, args[1]);
                return handleToggle(sender, null);
            }
            default -> {
                                if (args.length == 1) return handleToggle(sender, args[0]);
                sendHelp(sender, label);
                return true;
            }
        }
    }

    private boolean handleToggle(CommandSender sender, String targetName) {
        if (targetName == null) {
                        if (!(sender instanceof Player player)) {
                sender.sendMessage(config.getMessage("player-only"));
                return true;
            }
            if (!player.hasPermission("placeanywhere.toggle")) {
                player.sendMessage(config.getMessage("no-permission"));
                return true;
            }
            boolean nowActive = playerData.toggle(player);
            sendFeedback(player, nowActive);
            notifyAdmins(player, nowActive, sender);
            return true;
        }

                if (!sender.hasPermission("placeanywhere.toggle.others")) {
            sender.sendMessage(config.getMessage("no-permission"));
            return true;
        }
        Player target = Bukkit.getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(MessageUtil.replace(
                    config.getMessage("player-not-found"), "{player}", targetName));
            return true;
        }

        boolean nowActive = playerData.toggle(target);
        String msgKey = nowActive ? "toggled-other-on" : "toggled-other-off";
        sender.sendMessage(MessageUtil.replace(config.getMessage(msgKey), "{player}", target.getName()));

                sendFeedback(target, nowActive);
        return true;
    }

    private boolean handleSetState(CommandSender sender, String targetName, boolean enable) {
        Player target;
        if (targetName == null) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(config.getMessage("player-only"));
                return true;
            }
            target = p;
            if (!target.hasPermission("placeanywhere.toggle")) {
                target.sendMessage(config.getMessage("no-permission"));
                return true;
            }
        } else {
            if (!sender.hasPermission("placeanywhere.toggle.others")) {
                sender.sendMessage(config.getMessage("no-permission"));
                return true;
            }
            target = Bukkit.getPlayer(targetName);
            if (target == null) {
                sender.sendMessage(MessageUtil.replace(
                        config.getMessage("player-not-found"), "{player}", targetName));
                return true;
            }
        }

        if (enable) {
            playerData.enable(target);
        } else {
            playerData.disable(target);
        }

        sendFeedback(target, enable);
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("placeanywhere.reload")) {
            sender.sendMessage(config.getMessage("no-permission"));
            return true;
        }
        plugin.reload();
        sender.sendMessage(config.getMessage("reload"));
        return true;
    }

    private boolean handleInfo(CommandSender sender) {
        if (!sender.hasPermission("placeanywhere.use")) {
            sender.sendMessage(config.getMessage("no-permission"));
            return true;
        }

        sender.sendMessage(config.getRawMessage("info-header"));

        String status = "N/D";
        if (sender instanceof Player player) {
            status = playerData.isActive(player)
                    ? "§aATTIVO"
                    : "§cINATTIVO";
        }

        sender.sendMessage(MessageUtil.replace(config.getRawMessage("info-status"), "{status}", status));
        sender.sendMessage(MessageUtil.replace(config.getRawMessage("info-mode"),
                "{mode}", config.getDefaultMode()));
        sender.sendMessage(MessageUtil.replace(config.getRawMessage("info-version"),
                "{version}", plugin.getDescription().getVersion()));
        sender.sendMessage(config.getRawMessage("info-author"));

        if (sender instanceof Player player && playerData.isActive(player)) {
            long durationMs = playerData.getSessionDuration(player);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(durationMs);
            long seconds = TimeUnit.MILLISECONDS.toSeconds(durationMs) % 60;
            player.sendMessage("  §7Sessione attiva da: §e" + minutes + "m " + seconds + "s");
            player.sendMessage("  §7Blocchi piazzati questa sessione: §e" + playerData.getPlacementCount(player));
        }
        return true;
    }

    private boolean handleList(CommandSender sender) {
        if (!sender.hasPermission("placeanywhere.use")) {
            sender.sendMessage(config.getMessage("no-permission"));
            return true;
        }

        sender.sendMessage(config.getRawMessage("list-header"));
        var activePlayers = playerData.getActivePlayers();

        if (activePlayers.isEmpty()) {
            sender.sendMessage(config.getRawMessage("list-empty"));
            return true;
        }

        for (UUID uuid : activePlayers) {
            Player p = Bukkit.getPlayer(uuid);
            String name = p != null ? p.getName() : uuid.toString().substring(0, 8) + "...";
            sender.sendMessage(MessageUtil.replace(config.getRawMessage("list-entry"), "{player}", name));
        }
        return true;
    }

    private void sendFeedback(Player player, boolean enabled) {
        if (!config.isShowToggleFeedback()) return;

        String message = enabled ? config.getMessage("enabled") : config.getMessage("disabled");
        String feedbackType = config.getFeedbackType();

        switch (feedbackType.toUpperCase()) {
            case "ACTIONBAR" -> player.sendActionBar(message);
            case "TITLE" -> player.sendTitle(
                    enabled ? "§aPlaceAnywhere" : "§cPlaceAnywhere",
                    enabled ? "§7Modalità attivata" : "§7Modalità disattivata",
                    10, 40, 10);
            case "CHAT" -> player.sendMessage(message);
            case "ALL" -> {
                player.sendMessage(message);
                player.sendActionBar(message);
            }
            default -> player.sendMessage(message);
        }

                if (config.isSoundEnabled()) {
            try {
                String soundName = enabled ? config.getSoundOn() : config.getSoundOff();
                player.playSound(player.getLocation(), Sound.valueOf(soundName), 1.0f, 1.0f);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    private void notifyAdmins(Player actor, boolean enabled, CommandSender exclude) {
        if (!config.isNotifyAdmins()) return;

        String action = enabled ? "attivato" : "disattivato";
        String msg = MessageUtil.replace(
                config.getMessage("notify-admin"),
                "{player}", actor.getName(),
                "{action}", action);

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(actor)) continue;
            if (p.hasPermission("placeanywhere.notify")) {
                p.sendMessage(msg);
            }
        }
    }

    private void sendHelp(CommandSender sender, String label) {
        sender.sendMessage("§8§m-----------§r §6PlaceAnywhere Help §8§m-----------");
        sender.sendMessage("§e/" + label + " §7- Toggle PlaceAnywhere per te");
        sender.sendMessage("§e/" + label + " on/off §7- Attiva o disattiva esplicitamente");
        sender.sendMessage("§e/" + label + " <giocatore> §7- Toggle per un altro giocatore");
        sender.sendMessage("§e/" + label + " list §7- Lista giocatori con modalità attiva");
        sender.sendMessage("§e/" + label + " info §7- Info e statistiche sessione");
        sender.sendMessage("§e/" + label + " reload §7- Ricarica la configurazione");
        sender.sendMessage("§8§m----------------------------------------");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
                        List<String> completions = new ArrayList<>(Arrays.asList("toggle", "on", "off", "info", "list", "reload"));
            return completions.stream()
                    .filter(s -> s.toLowerCase().startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }

                if (args.length == 2 && sender.hasPermission("placeanywhere.toggle.others")) {
            String sub = args[0].toLowerCase();
            if (sub.equals("on") || sub.equals("off") || sub.equals("toggle")) {
                return Bukkit.getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(s -> s.toLowerCase().startsWith(args[1].toLowerCase()))
                        .collect(Collectors.toList());
            }
        }

        return new ArrayList<>();
    }
}
