package dev.mastercraft.placeanywhere.managers;

import dev.mastercraft.placeanywhere.PlaceAnywhere;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class PlayerDataManager {

    private final PlaceAnywhere plugin;
    private final Set<UUID> activePlayers = new HashSet<>();
    private final Map<UUID, Long> sessionStartTime = new HashMap<>();
    private final Map<UUID, Integer> placementCount = new HashMap<>();
    private File dataFile;
    private FileConfiguration dataConfig;

    public PlayerDataManager(PlaceAnywhere plugin) {
        this.plugin = plugin;
    }

    public void load() {
        String storageType = plugin.getConfig().getString("storage.type", "YAML");
        if (!storageType.equalsIgnoreCase("YAML")) return;

        String fileName = plugin.getConfig().getString("storage.file", "playerdata.yml");
        dataFile = new File(plugin.getDataFolder(), fileName);
        if (!dataFile.exists()) {
            try {
                dataFile.getParentFile().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Impossibile creare playerdata.yml: " + e.getMessage());
                return;
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);

                if (plugin.getConfig().getString("settings.default-mode", "TOGGLE").equalsIgnoreCase("PERSISTENT")) {
            List<String> persistentPlayers = dataConfig.getStringList("persistent-active");
            for (String uuidStr : persistentPlayers) {
                try {
                    activePlayers.add(UUID.fromString(uuidStr));
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("UUID non valido in playerdata.yml: " + uuidStr);
                }
            }
        }
    }

    public void save() {
        if (dataConfig == null) return;
        if (plugin.getConfig().getString("settings.default-mode", "TOGGLE").equalsIgnoreCase("PERSISTENT")) {
            List<String> persistentPlayers = new ArrayList<>();
            for (UUID uuid : activePlayers) {
                persistentPlayers.add(uuid.toString());
            }
            dataConfig.set("persistent-active", persistentPlayers);
            try {
                dataConfig.save(dataFile);
            } catch (IOException e) {
                plugin.getLogger().severe("Impossibile salvare playerdata.yml: " + e.getMessage());
            }
        }
    }

    public boolean isActive(Player player) {
        return activePlayers.contains(player.getUniqueId());
    }

    public boolean isActive(UUID uuid) {
        return activePlayers.contains(uuid);
    }

    public void enable(Player player) {
        activePlayers.add(player.getUniqueId());
        sessionStartTime.put(player.getUniqueId(), System.currentTimeMillis());
        placementCount.put(player.getUniqueId(), 0);
        if (plugin.getConfig().getString("settings.log-placements", "false").equals("true")) {
            plugin.getLogger().info("[PlaceAnywhere] " + player.getName() + " ha attivato PlaceAnywhere.");
        }
    }

    public void disable(Player player) {
        activePlayers.remove(player.getUniqueId());
        sessionStartTime.remove(player.getUniqueId());
    }

    public boolean toggle(Player player) {
        if (isActive(player)) {
            disable(player);
            return false;
        } else {
            enable(player);
            return true;
        }
    }

    public void incrementPlacementCount(Player player) {
        placementCount.merge(player.getUniqueId(), 1, Integer::sum);
    }

    public int getPlacementCount(Player player) {
        return placementCount.getOrDefault(player.getUniqueId(), 0);
    }

    public long getSessionDuration(Player player) {
        Long start = sessionStartTime.get(player.getUniqueId());
        if (start == null) return 0;
        return System.currentTimeMillis() - start;
    }

    public Set<UUID> getActivePlayers() {
        return Collections.unmodifiableSet(activePlayers);
    }

    public void onPlayerQuit(Player player) {
        String mode = plugin.getConfig().getString("settings.default-mode", "TOGGLE");
        if (mode.equalsIgnoreCase("TOGGLE")) {
                        activePlayers.remove(player.getUniqueId());
            sessionStartTime.remove(player.getUniqueId());
            placementCount.remove(player.getUniqueId());
        }
    }
}
